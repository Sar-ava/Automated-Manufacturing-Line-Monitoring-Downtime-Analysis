import pandas as pd
import numpy as np
import random
from datetime import datetime, timedelta


machines = ['ATE DDR4', 'ATE DDR5', 'ATE DDR5']
shift_hours = 9
data_frequency_minutes = 1 


start_time = datetime(2025, 7, 3, 5, 3, 0)  
timestamps = [start_time + timedelta(minutes=i) for i in range(shift_hours * 60)]


data = []

for timestamp in timestamps:
    for machine in machines:
        status = random.choices(['Running', 'Stopped'], weights=[0.1, 0.9])[0]
        downtime_reason = random.choice(['None', 'Mechanical Failure', 'Power Loss', 'Software Issue']) if status == 'Stopped' else 'None'
        data.append({
            'Timestamp': timestamp,
            'Machine': machine,
            'Status': status,
            'Downtime Reason': downtime_reason
        })


df = pd.DataFrame(data)


df.to_csv('manufacturing_line_data.csv', index=False)

print(df.head())
